# CHU — Creative Humanity Universe

Where creativity meets opportunity.
Founded by Felix Samahanda, from Zambia.

A global platform connecting musicians, writers, filmmakers, artists, and
innovators with mentors, opportunities, and community.

## What's included

- **Home** — hero, vision/mission/founder message, animated "orbit" of the
  five talent categories
- **Discover** — search + filter creators, view individual creator profiles
- **Creator profiles** — dedicated `/creator/:id` page, plus a "Join CHU"
  form to create your own
- **Mentorship Hub** — find a mentor / become a mentor
- **Opportunities Board** — competitions, grants, jobs, collaborations —
  save and apply
- **Community** — a shareable post feed
- **CHU Academy** — course/workshop catalog with category filters
- **Dashboard** — your profile, saved opportunities, connections,
  notifications

Data currently lives in `src/data/seedData.js` (mock creators, mentors,
opportunities, courses, posts) and everything you create (your profile,
posts, connections, saves) persists in the browser via `localStorage`, so
it survives a refresh. There's no backend yet — see "Next steps" below.

## Tech stack

- React 18 + Vite
- React Router (`HashRouter`, so it works when loaded from a local file —
  required for Capacitor)
- Tailwind CSS for styling
- lucide-react for icons
- Capacitor, pre-configured for an Android build

## Project structure

```
chu-app/
├── index.html
├── package.json
├── vite.config.js
├── tailwind.config.js
├── postcss.config.js
├── capacitor.config.json
└── src/
    ├── main.jsx              # entry point, router + context providers
    ├── App.jsx                # routes + layout + footer
    ├── index.css              # fonts, Tailwind layers, custom component classes
    ├── context/
    │   └── AppContext.jsx     # global state + localStorage persistence
    ├── data/
    │   └── seedData.js        # categories + mock creators/mentors/etc.
    ├── components/
    │   ├── Navbar.jsx
    │   ├── Orbit.jsx           # homepage hero visualization
    │   ├── ProfileModal.jsx    # create/edit profile form
    │   └── UI.jsx              # Pill, CatTag, Avatar, Toast
    └── pages/
        ├── Home.jsx
        ├── Discover.jsx
        ├── CreatorProfilePage.jsx
        ├── Mentorship.jsx
        ├── Opportunities.jsx
        ├── Community.jsx
        ├── Academy.jsx
        └── Dashboard.jsx
```

## Running it locally

Requires [Node.js](https://nodejs.org) 18+.

```bash
cd chu-app
npm install
npm run dev
```

Open the URL Vite prints (usually `http://localhost:5173`).

To build a production bundle:

```bash
npm run build      # outputs to dist/
npm run preview    # serve the production build locally to check it
```

## Turning this into an Android app (Capacitor)

The project is already set up for this — `capacitor.config.json` exists
and `@capacitor/core`, `@capacitor/android`, and `@capacitor/cli` are in
`package.json`. From the project root, once dependencies are installed:

```bash
# 1. Build the web app
npm run build

# 2. Add the Android platform (first time only — creates an android/ folder)
npx cap add android

# 3. Copy the web build into the native project
npx cap sync

# 4. Open it in Android Studio to run on an emulator or device
npx cap open android
```

From Android Studio you can run it on a connected device/emulator, or
build a signed APK/AAB via **Build → Generate Signed Bundle / APK**.

Notes for the Android build:
- The router uses `HashRouter` specifically so navigation keeps working
  when the app is served from the local filesystem inside the WebView.
- `vite.config.js` sets `base: "./"` so built asset paths are relative,
  which is required for the same reason.
- If you add real network calls later (e.g. to a backend API), make sure
  `capacitor.config.json`'s `server` settings and Android's network
  security config allow it.

## Next steps (not included yet)

This is a fully working front-end with local persistence — a real product
launch would need:
- A backend (auth, a database for creators/posts/opportunities, file
  storage for images/portfolios)
- Real image uploads for profile pictures and project media
- Real messaging (the Dashboard has a placeholder for it)
- Push notifications (Capacitor has a plugin for this once there's a
  backend to trigger them)

Happy to help build any of these next.
