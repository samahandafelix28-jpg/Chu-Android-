import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Relative base so the build works when loaded from the filesystem
// inside a Capacitor Android WebView (file:// origin, no server).
export default defineConfig({
  plugins: [react()],
  base: "./",
  server: {
    port: 5173,
  },
});
