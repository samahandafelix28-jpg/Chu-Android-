import React, { useState } from "react";
import { Routes, Route, useNavigate } from "react-router-dom";
import Navbar from "./components/Navbar";
import ProfileModal from "./components/ProfileModal";
import { Toast } from "./components/UI";
import Home from "./pages/Home";
import Discover from "./pages/Discover";
import CreatorProfilePage from "./pages/CreatorProfilePage";
import Mentorship from "./pages/Mentorship";
import Opportunities from "./pages/Opportunities";
import Community from "./pages/Community";
import Academy from "./pages/Academy";
import Dashboard from "./pages/Dashboard";
import { useApp } from "./context/AppContext";

export default function App() {
  const [showProfileModal, setShowProfileModal] = useState(false);
  const { myProfile, saveProfile, toast, clearToast } = useApp();
  const navigate = useNavigate();

  const openJoin = () => {
    if (myProfile) navigate("/dashboard");
    else setShowProfileModal(true);
  };

  const handleSave = (profile) => {
    saveProfile(profile);
    setShowProfileModal(false);
    navigate("/dashboard");
  };

  return (
    <div className="min-h-screen">
      <Navbar onJoin={() => setShowProfileModal(true)} />

      <Routes>
        <Route path="/" element={<Home onJoin={openJoin} />} />
        <Route path="/discover" element={<Discover />} />
        <Route path="/creator/:id" element={<CreatorProfilePage />} />
        <Route path="/mentorship" element={<Mentorship />} />
        <Route path="/opportunities" element={<Opportunities />} />
        <Route path="/community" element={<Community />} />
        <Route path="/academy" element={<Academy />} />
        <Route path="/dashboard" element={<Dashboard onEditProfile={() => setShowProfileModal(true)} />} />
        <Route path="*" element={<Home onJoin={openJoin} />} />
      </Routes>

      <footer className="max-w-[1180px] mx-auto px-5 pt-8 pb-12 mt-5 flex justify-between items-center flex-wrap gap-2.5 text-mist text-xs border-t border-white/10">
        <span>Creative Humanity Universe · Where creativity meets opportunity.</span>
        <span>Founded by Felix Samahanda, from Zambia</span>
      </footer>

      {showProfileModal && (
        <ProfileModal
          initial={myProfile}
          onClose={() => setShowProfileModal(false)}
          onSave={handleSave}
        />
      )}
      {toast && <Toast message={toast} onDone={clearToast} />}
    </div>
  );
}
