import React, { useState } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import {
  Globe2, Search, Users, Briefcase, MessageCircle, GraduationCap,
  LayoutDashboard, Sparkles, Menu, X,
} from "lucide-react";

const NAV_ITEMS = [
  ["/", "Home", Globe2],
  ["/discover", "Discover", Search],
  ["/mentorship", "Mentorship", Users],
  ["/opportunities", "Opportunities", Briefcase],
  ["/community", "Community", MessageCircle],
  ["/academy", "Academy", GraduationCap],
  ["/dashboard", "Dashboard", LayoutDashboard],
];

export default function Navbar({ onJoin }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const navigate = useNavigate();

  const linkClass = ({ isActive }) =>
    "flex items-center gap-1.5 text-[13.5px] font-body px-2.5 py-2 rounded-lg whitespace-nowrap transition-colors " +
    (isActive ? "bg-gold text-ink font-semibold" : "text-mist hover:text-paper hover:bg-white/5");

  return (
    <header className="sticky top-0 z-40 bg-ink/85 backdrop-blur-md border-b border-white/10">
      <div className="max-w-[1180px] mx-auto flex items-center gap-6 px-5 py-3">
        <button className="flex items-center gap-2 bg-transparent border-none cursor-pointer" onClick={() => navigate("/")}>
          <span className="w-7 h-7 rounded-lg bg-gold flex items-center justify-center">
            <Sparkles size={16} color="#14102B" />
          </span>
          <span className="font-display font-bold text-lg tracking-wide text-paper">CHU</span>
        </button>

        <nav className="hidden md:flex gap-1 flex-1">
          {NAV_ITEMS.map(([to, label, Icon]) => (
            <NavLink key={to} to={to} end={to === "/"} className={linkClass}>
              <Icon size={14} />
              {label}
            </NavLink>
          ))}
        </nav>

        <div className="flex items-center gap-2.5 ml-auto md:ml-0">
          <button className="btn btn-gold btn-sm" onClick={onJoin}>Join CHU</button>
          <button className="md:hidden bg-transparent border-none text-paper cursor-pointer" onClick={() => setMobileOpen((v) => !v)}>
            {mobileOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {mobileOpen && (
        <div className="md:hidden flex flex-col gap-1 px-5 pb-4 border-t border-white/10">
          {NAV_ITEMS.map(([to, label, Icon]) => (
            <NavLink key={to} to={to} end={to === "/"} className={linkClass} onClick={() => setMobileOpen(false)}>
              <Icon size={14} />
              {label}
            </NavLink>
          ))}
        </div>
      )}
    </header>
  );
}
