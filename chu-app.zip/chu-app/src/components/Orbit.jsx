import React from "react";
import { Sparkles } from "lucide-react";
import { CATS } from "../data/seedData";

export default function Orbit({ onPick }) {
  return (
    <div className="orbit-wrap">
      <div className="orbit-ring r1" />
      <div className="orbit-ring r2" />
      <div className="orbit-core">
        <Sparkles size={20} color="#14102B" />
        <span>CHU</span>
      </div>
      {CATS.map((c, i) => {
        const dur = 22 + i * 4;
        const delay = -(i * 3.4);
        const radius = i % 2 === 0 ? 128 : 168;
        const Icon = c.icon;
        return (
          <div
            key={c.id}
            className="orbit-item"
            style={{ animationDuration: `${dur}s`, animationDelay: `${delay}s`, "--r": `${radius}px` }}
          >
            <button
              className="orbit-node"
              style={{
                animationDuration: `${dur}s`,
                animationDelay: `${delay}s`,
                borderColor: c.color,
                boxShadow: `0 0 18px ${c.color}55`,
              }}
              onClick={() => onPick(c.id)}
              title={c.label}
              aria-label={`Explore ${c.label} creators`}
            >
              <Icon size={16} color={c.color} strokeWidth={2.2} />
            </button>
          </div>
        );
      })}
    </div>
  );
}
