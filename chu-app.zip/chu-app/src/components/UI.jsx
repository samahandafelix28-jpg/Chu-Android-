import React, { useEffect } from "react";
import { CheckCircle2 } from "lucide-react";
import { catById } from "../data/seedData";

export function Pill({ active, color, children, onClick }) {
  return (
    <button
      onClick={onClick}
      className="pill"
      style={{
        borderColor: active ? color : "rgba(184,179,217,0.35)",
        background: active ? color + "22" : "transparent",
        color: active ? "#F5F3FF" : "#B8B3D9",
      }}
    >
      {children}
    </button>
  );
}

export function CatTag({ id, small }) {
  const c = catById(id);
  const Icon = c.icon;
  return (
    <span className="cat-tag" style={{ color: c.color, borderColor: c.color + "55", fontSize: small ? 11 : 12 }}>
      <Icon size={small ? 11 : 13} strokeWidth={2.2} />
      {c.label}
    </span>
  );
}

export function Avatar({ name, cat, size = 40 }) {
  const c = catById(cat);
  return (
    <div
      className="rounded-full flex items-center justify-center font-display font-bold flex-shrink-0"
      style={{ width: size, height: size, background: c.color + "22", color: c.color, fontSize: size * 0.4 }}
    >
      {name ? name[0].toUpperCase() : "?"}
    </div>
  );
}

export function Toast({ message, onDone }) {
  useEffect(() => {
    const t = setTimeout(onDone, 2400);
    return () => clearTimeout(t);
  }, [onDone]);
  return (
    <div className="fixed bottom-6 left-1/2 -translate-x-1/2 bg-surface2 border border-mint/40 text-paper px-4 py-3 rounded-xl flex items-center gap-2 text-sm z-[200] shadow-2xl">
      <CheckCircle2 size={16} color="#4ECCA3" />
      {message}
    </div>
  );
}
