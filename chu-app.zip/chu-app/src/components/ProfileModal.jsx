import React, { useState } from "react";
import { X, Sparkles } from "lucide-react";
import { CATS } from "../data/seedData";

export default function ProfileModal({ initial, onClose, onSave }) {
  const [form, setForm] = useState(
    initial || { name: "", location: "", cat: "music", bio: "", portfolio: "", achievements: "" }
  );

  const submit = (e) => {
    e.preventDefault();
    if (!form.name.trim() || !form.bio.trim()) return;
    onSave({ id: initial?.id, ...form });
  };

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-[100] flex items-center justify-center p-5" onClick={onClose}>
      <div
        className="bg-ink border border-white/20 rounded-2xl max-w-[520px] w-full max-h-[88vh] overflow-auto p-6"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-paper text-lg font-display">{initial ? "Edit your profile" : "Join CHU"}</h3>
          <button className="icon-btn" onClick={onClose} aria-label="Close"><X size={18} /></button>
        </div>
        <form className="flex flex-col gap-3.5" onSubmit={submit}>
          <label className="flex flex-col gap-1.5 text-[12.5px] text-mist font-semibold">
            Name
            <input className="form-input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Your name" required />
          </label>
          <label className="flex flex-col gap-1.5 text-[12.5px] text-mist font-semibold">
            Location
            <input className="form-input" value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} placeholder="City, Country" />
          </label>
          <label className="flex flex-col gap-1.5 text-[12.5px] text-mist font-semibold">
            Talent category
            <select className="form-select" value={form.cat} onChange={(e) => setForm({ ...form, cat: e.target.value })}>
              {CATS.map((c) => <option key={c.id} value={c.id}>{c.label}</option>)}
            </select>
          </label>
          <label className="flex flex-col gap-1.5 text-[12.5px] text-mist font-semibold">
            Biography
            <textarea className="form-textarea" value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value })} placeholder="Tell the universe who you are" required />
          </label>
          <label className="flex flex-col gap-1.5 text-[12.5px] text-mist font-semibold">
            Portfolio link
            <input className="form-input" value={form.portfolio} onChange={(e) => setForm({ ...form, portfolio: e.target.value })} placeholder="yourwork.com" />
          </label>
          <label className="flex flex-col gap-1.5 text-[12.5px] text-mist font-semibold">
            Achievements
            <input className="form-input" value={form.achievements} onChange={(e) => setForm({ ...form, achievements: e.target.value })} placeholder="Awards, features, milestones" />
          </label>
          <button className="btn btn-gold" type="submit">
            <Sparkles size={15} /> {initial ? "Save changes" : "Create my profile"}
          </button>
        </form>
      </div>
    </div>
  );
}
