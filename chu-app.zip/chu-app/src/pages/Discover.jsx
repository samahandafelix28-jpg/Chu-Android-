import React, { useState, useMemo } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Search, MapPin, Award, ExternalLink, CheckCircle2 } from "lucide-react";
import { Pill, CatTag, Avatar } from "../components/UI";
import { CATS, catById } from "../data/seedData";
import { useApp } from "../context/AppContext";

export default function Discover() {
  const { creators, connected, connectWithCreator } = useApp();
  const [searchParams, setSearchParams] = useSearchParams();
  const filter = searchParams.get("cat");
  const [q, setQ] = useState("");
  const navigate = useNavigate();

  const setFilter = (catId) => {
    if (!catId) setSearchParams({});
    else setSearchParams({ cat: catId });
  };

  const filtered = useMemo(
    () =>
      creators.filter((c) => {
        const matchesCat = !filter || c.cat === filter;
        const matchesQ = !q || (c.name + c.location + c.bio).toLowerCase().includes(q.toLowerCase());
        return matchesCat && matchesQ;
      }),
    [creators, filter, q]
  );
  const featured = creators.slice(0, 3);

  return (
    <div className="max-w-[1180px] mx-auto px-5 py-11">
      <div className="mb-6">
        <h2 className="text-2xl text-paper mb-1.5">Discover Creators</h2>
        <p className="text-mist text-sm">Search the universe. Connect with people building something.</p>
      </div>

      <div className="mb-1.5">
        <div className="flex items-center gap-2.5 bg-surface border border-white/15 rounded-xl px-3.5 py-2.5 max-w-[420px]">
          <Search size={16} className="text-mist" />
          <input
            className="bg-transparent border-none outline-none text-paper text-sm w-full"
            placeholder="Search by name, place, or focus…"
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
        </div>
      </div>

      <div className="flex gap-2 flex-wrap my-3.5 mb-5">
        <Pill active={!filter} color="#F2B705" onClick={() => setFilter(null)}>All</Pill>
        {CATS.map((c) => (
          <Pill key={c.id} active={filter === c.id} color={c.color} onClick={() => setFilter(filter === c.id ? null : c.id)}>
            {c.label}
          </Pill>
        ))}
      </div>

      {!filter && !q && (
        <div className="mb-5">
          <span className="font-mono text-[11px] tracking-wide text-mist uppercase">Featured</span>
          <div className="flex gap-2.5 mt-2.5 flex-wrap">
            {featured.map((c) => (
              <button
                key={c.id}
                className="flex items-center gap-2.5 bg-surface border rounded-xl px-3.5 py-2.5 text-left"
                style={{ borderColor: catById(c.cat).color + "40" }}
                onClick={() => navigate(`/creator/${c.id}`)}
              >
                <Avatar name={c.name} cat={c.cat} />
                <div>
                  <div className="font-semibold text-paper text-[14.5px]">{c.name}</div>
                  <CatTag id={c.cat} small />
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((c) => (
          <div key={c.id} className="card flex flex-col gap-2.5">
            <button className="flex items-center gap-2.5 text-left" onClick={() => navigate(`/creator/${c.id}`)}>
              <Avatar name={c.name} cat={c.cat} />
              <div>
                <div className="font-semibold text-paper text-[14.5px]">{c.name}</div>
                <div className="flex items-center gap-1 text-mist text-xs"><MapPin size={11} /> {c.location}</div>
              </div>
            </button>
            <CatTag id={c.cat} />
            <p className="text-[13.5px]">{c.bio}</p>
            {c.achievements && <div className="flex items-center gap-1.5 text-xs text-mist"><Award size={12} /> {c.achievements}</div>}
            {c.portfolio && <div className="flex items-center gap-1.5 text-xs text-mist"><ExternalLink size={12} /> {c.portfolio}</div>}
            <button
              className={"btn btn-sm " + (connected.has(c.id) ? "btn-connected" : "btn-outline")}
              onClick={() => connectWithCreator(c.id)}
              disabled={connected.has(c.id)}
            >
              {connected.has(c.id) ? <><CheckCircle2 size={13} /> Connected</> : "Connect"}
            </button>
          </div>
        ))}
        {filtered.length === 0 && <p className="text-mist">No creators match yet — try a different search or category.</p>}
      </div>
    </div>
  );
}
