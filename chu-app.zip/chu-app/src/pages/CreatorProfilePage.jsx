import React from "react";
import { useParams, useNavigate } from "react-router-dom";
import { ArrowLeft, MapPin, Award, ExternalLink, CheckCircle2 } from "lucide-react";
import { CatTag, Avatar } from "../components/UI";
import { useApp } from "../context/AppContext";

export default function CreatorProfilePage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { creators, connected, connectWithCreator, myProfile } = useApp();
  const creator = creators.find((c) => c.id === id);

  if (!creator) {
    return (
      <div className="max-w-[1180px] mx-auto px-5 py-11">
        <button className="btn btn-ghost btn-sm mb-6" onClick={() => navigate("/discover")}>
          <ArrowLeft size={14} /> Back to Discover
        </button>
        <p className="text-mist">This creator profile doesn't exist, or hasn't been created yet.</p>
      </div>
    );
  }

  const isMe = myProfile && myProfile.id === creator.id;

  return (
    <div className="max-w-[720px] mx-auto px-5 py-11">
      <button className="btn btn-ghost btn-sm mb-6" onClick={() => navigate("/discover")}>
        <ArrowLeft size={14} /> Back to Discover
      </button>

      <div className="card flex flex-col gap-4">
        <div className="flex items-center gap-4">
          <Avatar name={creator.name} cat={creator.cat} size={64} />
          <div>
            <h2 className="text-2xl text-paper">{creator.name}</h2>
            {creator.location && (
              <div className="flex items-center gap-1 text-mist text-sm mt-1"><MapPin size={13} /> {creator.location}</div>
            )}
          </div>
        </div>

        <CatTag id={creator.cat} />
        <p className="text-[14.5px] leading-relaxed">{creator.bio}</p>

        {creator.achievements && (
          <div className="flex items-center gap-2 text-sm text-mist"><Award size={14} /> {creator.achievements}</div>
        )}
        {creator.portfolio && (
          <div className="flex items-center gap-2 text-sm text-mist"><ExternalLink size={14} /> {creator.portfolio}</div>
        )}

        {!isMe && (
          <button
            className={"btn " + (connected.has(creator.id) ? "btn-connected" : "btn-gold") + " w-fit"}
            onClick={() => connectWithCreator(creator.id)}
            disabled={connected.has(creator.id)}
          >
            {connected.has(creator.id) ? <><CheckCircle2 size={15} /> Connected</> : "Connect"}
          </button>
        )}
      </div>
    </div>
  );
}
