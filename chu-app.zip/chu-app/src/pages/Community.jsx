import React, { useState } from "react";
import { Send } from "lucide-react";
import { CatTag, Avatar } from "../components/UI";
import { CATS } from "../data/seedData";
import { useApp } from "../context/AppContext";

function timeAgo(ts) {
  const mins = Math.round((Date.now() - ts) / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.round(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.round(hrs / 24)}d ago`;
}

export default function Community() {
  const { posts, addPost, myProfile } = useApp();
  const [text, setText] = useState("");
  const [cat, setCat] = useState("music");

  const submit = (e) => {
    e.preventDefault();
    if (!text.trim()) return;
    addPost({ author: myProfile?.name || "You", cat, text: text.trim() });
    setText("");
  };

  return (
    <div className="max-w-[1180px] mx-auto px-5 py-11">
      <div className="mb-6">
        <h2 className="text-2xl text-paper mb-1.5">Community</h2>
        <p className="text-mist text-sm">Share work in progress. Find your next collaborator.</p>
      </div>

      <form className="card mb-6" onSubmit={submit}>
        <textarea
          className="form-textarea"
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Share a post, ask for feedback, or find a collaborator…"
        />
        <div className="flex justify-between items-center mt-2.5 gap-2.5 flex-wrap">
          <select className="form-select w-auto" value={cat} onChange={(e) => setCat(e.target.value)}>
            {CATS.map((c) => <option key={c.id} value={c.id}>{c.label}</option>)}
          </select>
          <button className="btn btn-gold btn-sm" type="submit"><Send size={13} /> Post</button>
        </div>
      </form>

      <div className="flex flex-col gap-3">
        {posts.slice().sort((a, b) => b.ts - a.ts).map((p) => (
          <div key={p.id} className="card flex flex-col gap-2.5">
            <div className="flex items-center gap-2.5">
              <Avatar name={p.author} cat={p.cat} />
              <div>
                <div className="font-semibold text-paper text-[14.5px]">{p.author}</div>
                <div className="text-mist text-xs">{timeAgo(p.ts)}</div>
              </div>
            </div>
            <CatTag id={p.cat} small />
            <p className="text-[13.5px]">{p.text}</p>
          </div>
        ))}
        {posts.length === 0 && <p className="text-mist">No posts yet — be the first to share something.</p>}
      </div>
    </div>
  );
}
