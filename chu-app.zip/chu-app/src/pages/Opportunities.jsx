import React, { useState } from "react";
import { Bell, Bookmark, CheckCircle2 } from "lucide-react";
import { Pill, CatTag } from "../components/UI";
import { CATS } from "../data/seedData";
import { useApp } from "../context/AppContext";

const TYPE_COLOR = { Competition: "#F2B705", Grant: "#4ECCA3", Job: "#4EA8DE", Collaboration: "#9B6BFF" };

export default function Opportunities() {
  const { opportunities, saved, toggleSaveOpportunity, applied, applyToOpportunity } = useApp();
  const [filter, setFilter] = useState(null);
  const filtered = filter ? opportunities.filter((o) => o.cat === filter) : opportunities;

  return (
    <div className="max-w-[1180px] mx-auto px-5 py-11">
      <div className="mb-6">
        <h2 className="text-2xl text-paper mb-1.5">Opportunities Board</h2>
        <p className="text-mist text-sm">Competitions, grants, jobs, and collaborations — open right now.</p>
      </div>

      <div className="flex gap-2 flex-wrap mb-6">
        <Pill active={!filter} color="#F2B705" onClick={() => setFilter(null)}>All</Pill>
        {CATS.map((c) => (
          <Pill key={c.id} active={filter === c.id} color={c.color} onClick={() => setFilter(filter === c.id ? null : c.id)}>{c.label}</Pill>
        ))}
      </div>

      <div className="flex flex-col gap-3">
        {filtered.map((o) => (
          <div key={o.id} className="card">
            <div className="flex justify-between items-center mb-2">
              <span className="font-mono text-[11px] border rounded-md px-2 py-1" style={{ color: TYPE_COLOR[o.type], borderColor: TYPE_COLOR[o.type] + "55" }}>
                {o.type}
              </span>
              <CatTag id={o.cat} small />
            </div>
            <h4 className="text-[16.5px] text-paper my-1">{o.title}</h4>
            <p className="text-[13.5px]">{o.desc}</p>
            <div className="flex justify-between items-center mt-3 flex-wrap gap-2.5">
              <span className="flex items-center gap-1.5 text-xs text-mist"><Bell size={12} /> Deadline: {o.deadline}</span>
              <div className="flex items-center gap-2">
                <button className="icon-btn" title="Save" onClick={() => toggleSaveOpportunity(o.id)}>
                  <Bookmark size={15} fill={saved.has(o.id) ? "#F2B705" : "none"} color={saved.has(o.id) ? "#F2B705" : "#B8B3D9"} />
                </button>
                <button
                  className={"btn btn-sm " + (applied.has(o.id) ? "btn-connected" : "btn-outline")}
                  onClick={() => applyToOpportunity(o.id)}
                  disabled={applied.has(o.id)}
                >
                  {applied.has(o.id) ? <><CheckCircle2 size={13} /> Applied</> : "Apply"}
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
