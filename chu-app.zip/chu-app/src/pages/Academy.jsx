import React, { useState } from "react";
import { BookOpen } from "lucide-react";
import { Pill, CatTag } from "../components/UI";
import { CATS, catById } from "../data/seedData";
import { useApp } from "../context/AppContext";

export default function Academy() {
  const { courses } = useApp();
  const [filter, setFilter] = useState(null);
  const filtered = filter ? courses.filter((k) => k.cat === filter) : courses;

  return (
    <div className="max-w-[1180px] mx-auto px-5 py-11">
      <div className="mb-6">
        <h2 className="text-2xl text-paper mb-1.5">CHU Academy</h2>
        <p className="text-mist text-sm">Courses, workshops, and tutorials to sharpen your craft.</p>
      </div>

      <div className="flex gap-2 flex-wrap mb-6">
        <Pill active={!filter} color="#F2B705" onClick={() => setFilter(null)}>All</Pill>
        {CATS.map((c) => (
          <Pill key={c.id} active={filter === c.id} color={c.color} onClick={() => setFilter(filter === c.id ? null : c.id)}>{c.label}</Pill>
        ))}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((k) => (
          <div key={k.id} className="card" style={{ borderColor: catById(k.cat).color + "40" }}>
            <div className="flex justify-between items-center mb-2">
              <CatTag id={k.cat} small />
              <span className="font-mono text-[10.5px] text-mist border border-white/25 rounded-md px-2 py-1">{k.level}</span>
            </div>
            <h4 className="text-[16px] text-paper mb-1.5">{k.title}</h4>
            <p className="text-[13.5px] mb-3">{k.desc}</p>
            <button className="btn btn-outline btn-sm"><BookOpen size={13} /> Start course</button>
          </div>
        ))}
      </div>
    </div>
  );
}
