import React from "react";
import { useNavigate } from "react-router-dom";
import { Plus, Bookmark, Users, Bell, Mail, ChevronRight, MapPin, CheckCircle2 } from "lucide-react";
import { CatTag, Avatar } from "../components/UI";
import { useApp } from "../context/AppContext";

export default function Dashboard({ onEditProfile }) {
  const { myProfile, saved, opportunities, connected, requested } = useApp();
  const navigate = useNavigate();
  const savedList = opportunities.filter((o) => saved.has(o.id));

  return (
    <div className="max-w-[1180px] mx-auto px-5 py-11">
      <div className="mb-6">
        <h2 className="text-2xl text-paper mb-1.5">My Dashboard</h2>
        <p className="text-mist text-sm">Everything you're building on CHU, in one place.</p>
      </div>

      {!myProfile ? (
        <div className="border border-dashed border-white/30 rounded-2xl p-10 text-center flex flex-col items-center gap-4">
          <p className="text-mist">You haven't set up a creator profile yet.</p>
          <button className="btn btn-gold" onClick={onEditProfile}><Plus size={15} /> Create your profile</button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="card bg-gradient-to-br from-surface2 to-surface border-gold/20 flex flex-col gap-2.5">
            <div className="flex items-center gap-2.5">
              <Avatar name={myProfile.name} cat={myProfile.cat} size={56} />
              <div>
                <div className="font-semibold text-paper text-[14.5px]">{myProfile.name}</div>
                <div className="flex items-center gap-1 text-mist text-xs"><MapPin size={11} /> {myProfile.location}</div>
              </div>
            </div>
            <CatTag id={myProfile.cat} />
            <p className="text-[13.5px]">{myProfile.bio}</p>
            <button className="btn btn-outline btn-sm w-fit" onClick={onEditProfile}>Edit profile</button>
          </div>

          <div className="card flex flex-col gap-2.5">
            <h3 className="flex items-center gap-2 text-[15px] text-paper"><Bookmark size={15} /> Saved opportunities ({savedList.length})</h3>
            {savedList.length === 0 ? (
              <p className="text-mist text-sm">Nothing saved yet — browse the Opportunities Board.</p>
            ) : (
              savedList.map((o) => (
                <div key={o.id} className="flex items-center gap-1.5 text-xs text-mist"><ChevronRight size={12} /> {o.title}</div>
              ))
            )}
            <button className="btn btn-ghost btn-sm w-fit" onClick={() => navigate("/opportunities")}>View board</button>
          </div>

          <div className="card flex flex-col gap-2.5">
            <h3 className="flex items-center gap-2 text-[15px] text-paper"><Users size={15} /> Connections ({connected.size})</h3>
            <p className="text-mist text-sm">Creators you've connected with on Discover.</p>
            <button className="btn btn-ghost btn-sm w-fit" onClick={() => navigate("/discover")}>Discover more</button>
          </div>

          <div className="card flex flex-col gap-2.5">
            <h3 className="flex items-center gap-2 text-[15px] text-paper"><Bell size={15} /> Notifications</h3>
            <div className="flex items-center gap-1.5 text-xs text-mist"><CheckCircle2 size={12} color="#4ECCA3" /> Profile created</div>
            {requested.size > 0 && (
              <div className="flex items-center gap-1.5 text-xs text-mist">
                <CheckCircle2 size={12} color="#4ECCA3" /> {requested.size} mentorship request(s) sent
              </div>
            )}
            <div className="flex items-center gap-1.5 text-xs text-mist"><Mail size={12} /> Messages — coming soon</div>
          </div>
        </div>
      )}
    </div>
  );
}
