import React from "react";
import { useNavigate } from "react-router-dom";
import { Rocket, ArrowRight, Globe2, Sparkles, Heart, Star, ChevronRight } from "lucide-react";
import Orbit from "../components/Orbit";
import { CATS } from "../data/seedData";
import { useApp } from "../context/AppContext";

export default function Home({ onJoin }) {
  const navigate = useNavigate();
  const { myProfile } = useApp();

  const goDiscover = (catId) => navigate(`/discover?cat=${catId}`);

  return (
    <div>
      <section className="max-w-[1180px] mx-auto px-5 pt-14 pb-5 flex items-center gap-10 flex-wrap">
        <div className="flex-[1_1_420px] min-w-[300px]">
          <span className="inline-flex items-center gap-1.5 font-mono text-[11.5px] tracking-wide text-gold border border-gold/35 px-2.5 py-1.5 rounded-full mb-4">
            <Rocket size={12} /> Founded by Felix Samahanda, from Zambia
          </span>
          <h1 className="text-paper font-bold leading-[1.08] text-[clamp(32px,5vw,52px)]">
            Creative Humanity Universe
          </h1>
          <p className="font-display italic text-gold text-lg mt-3.5">Where creativity meets opportunity.</p>
          <p className="text-mist text-[15.5px] mt-3.5 max-w-[440px] leading-relaxed">
            "Every person has a talent, idea, or story that deserves to be seen."
          </p>
          <div className="flex gap-3 mt-7 flex-wrap">
            <button className="btn btn-gold" onClick={onJoin}>
              {myProfile ? "View my profile" : "Join CHU"} <ArrowRight size={15} />
            </button>
            <button className="btn btn-ghost" onClick={() => navigate("/discover")}>Explore Creators</button>
          </div>
        </div>
        <Orbit onPick={goDiscover} />
      </section>

      <section className="max-w-[1180px] mx-auto px-5 py-11 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="card">
          <h3 className="flex items-center gap-2 text-[15px] text-gold mb-2.5"><Globe2 size={16} /> Our Vision</h3>
          <p className="text-[13.5px]">A world where young creators have opportunities to express themselves, connect with others, and turn their creativity into something meaningful.</p>
        </div>
        <div className="card">
          <h3 className="flex items-center gap-2 text-[15px] text-gold mb-2.5"><Sparkles size={16} /> Our Mission</h3>
          <p className="text-[13.5px]">To empower the next generation of creators by giving them a platform where creativity, technology, and human connection come together.</p>
        </div>
        <div className="card">
          <h3 className="flex items-center gap-2 text-[15px] text-gold mb-2.5"><Heart size={16} /> Why CHU</h3>
          <p className="text-[13.5px]">A song can inspire millions. A story can change a life. An idea can build a better future — every voice here has something worth contributing.</p>
        </div>
        <div className="card bg-gradient-to-br from-surface2 to-surface border-gold/25">
          <h3 className="flex items-center gap-2 text-[15px] text-gold mb-2.5"><Star size={16} /> Founder's Message</h3>
          <p className="text-[13.5px]">"I created CHU because I believe creativity has the power to unite people and create opportunities. I'm building this from Zambia, connecting creative minds worldwide."</p>
          <span className="block mt-2.5 font-mono text-[11.5px] text-mist">— Felix Samahanda</span>
        </div>
      </section>

      <section className="max-w-[1180px] mx-auto px-5 py-11">
        <div className="mb-6">
          <h2 className="text-2xl text-paper mb-1.5">Five worlds, one universe</h2>
          <p className="text-mist text-sm">Pick a category to explore creators, or start your own orbit.</p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {CATS.map((c) => {
            const Icon = c.icon;
            return (
              <button
                key={c.id}
                className="flex items-center gap-2.5 bg-surface border rounded-xl p-3.5 text-paper cursor-pointer text-[13.5px] font-semibold text-left hover:-translate-y-0.5 transition-transform"
                style={{ borderColor: c.color + "40" }}
                onClick={() => goDiscover(c.id)}
              >
                <span
                  className="w-8.5 h-8.5 rounded-lg flex items-center justify-center flex-shrink-0"
                  style={{ background: c.color + "1a", color: c.color, width: 34, height: 34 }}
                >
                  <Icon size={20} />
                </span>
                <span className="flex-1">{c.label}</span>
                <ChevronRight size={15} className="text-mist" />
              </button>
            );
          })}
        </div>
      </section>
    </div>
  );
}
