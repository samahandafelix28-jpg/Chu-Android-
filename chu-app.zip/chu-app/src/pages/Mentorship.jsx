import React, { useState } from "react";
import { CheckCircle2, Plus } from "lucide-react";
import { CatTag, Avatar } from "../components/UI";
import { CATS } from "../data/seedData";
import { useApp } from "../context/AppContext";

export default function Mentorship() {
  const { mentors, addMentor, requested, requestMentor } = useApp();
  const [tab, setTab] = useState("find");
  const [form, setForm] = useState({ name: "", role: "", cat: "music", bio: "" });

  const submit = (e) => {
    e.preventDefault();
    if (!form.name.trim() || !form.bio.trim()) return;
    addMentor(form);
    setForm({ name: "", role: "", cat: "music", bio: "" });
    setTab("find");
  };

  return (
    <div className="max-w-[1180px] mx-auto px-5 py-11">
      <div className="mb-6">
        <h2 className="text-2xl text-paper mb-1.5">Mentorship Hub</h2>
        <p className="text-mist text-sm">Guidance, one conversation at a time.</p>
      </div>

      <div className="flex gap-1.5 mb-6 bg-surface rounded-xl p-1 w-fit">
        <button
          className={"text-[13px] font-semibold px-4 py-2.5 rounded-lg " + (tab === "find" ? "bg-gold text-ink" : "text-mist")}
          onClick={() => setTab("find")}
        >
          Find a mentor
        </button>
        <button
          className={"text-[13px] font-semibold px-4 py-2.5 rounded-lg " + (tab === "become" ? "bg-gold text-ink" : "text-mist")}
          onClick={() => setTab("become")}
        >
          Become a mentor
        </button>
      </div>

      {tab === "find" ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {mentors.map((m) => (
            <div key={m.id} className="card flex flex-col gap-2.5">
              <div className="flex items-center gap-2.5">
                <Avatar name={m.name} cat={m.cat} />
                <div>
                  <div className="font-semibold text-paper text-[14.5px]">{m.name}</div>
                  <div className="text-mist text-xs">{m.role}</div>
                </div>
              </div>
              <CatTag id={m.cat} />
              <p className="text-[13.5px]">{m.bio}</p>
              <button
                className={"btn btn-sm " + (requested.has(m.id) ? "btn-connected" : "btn-outline")}
                onClick={() => requestMentor(m.id)}
                disabled={requested.has(m.id)}
              >
                {requested.has(m.id) ? <><CheckCircle2 size={13} /> Requested</> : "Request guidance"}
              </button>
            </div>
          ))}
        </div>
      ) : (
        <form className="card flex flex-col gap-3.5 max-w-[480px]" onSubmit={submit}>
          <label className="flex flex-col gap-1.5 text-[12.5px] text-mist font-semibold">
            Name
            <input className="form-input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Your name" required />
          </label>
          <label className="flex flex-col gap-1.5 text-[12.5px] text-mist font-semibold">
            Role / background
            <input className="form-input" value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })} placeholder="e.g. Producer, 8 years in indie music" />
          </label>
          <label className="flex flex-col gap-1.5 text-[12.5px] text-mist font-semibold">
            Talent category you mentor in
            <select className="form-select" value={form.cat} onChange={(e) => setForm({ ...form, cat: e.target.value })}>
              {CATS.map((c) => <option key={c.id} value={c.id}>{c.label}</option>)}
            </select>
          </label>
          <label className="flex flex-col gap-1.5 text-[12.5px] text-mist font-semibold">
            How you can help
            <textarea className="form-textarea" value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value })} placeholder="What kind of guidance can you offer?" required />
          </label>
          <button className="btn btn-gold" type="submit"><Plus size={15} /> Create mentor profile</button>
        </form>
      )}
    </div>
  );
}
