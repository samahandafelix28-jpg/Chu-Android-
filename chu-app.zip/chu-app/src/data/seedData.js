import { Music2, PenLine, Clapperboard, Palette, Lightbulb } from "lucide-react";

export const CATS = [
  { id: "music", label: "Music", icon: Music2, color: "#F2B705" },
  { id: "writing", label: "Writing & Poetry", icon: PenLine, color: "#E8543E" },
  { id: "film", label: "Film & Storytelling", icon: Clapperboard, color: "#4EA8DE" },
  { id: "art", label: "Art & Design", icon: Palette, color: "#9B6BFF" },
  { id: "innovation", label: "Innovation", icon: Lightbulb, color: "#4ECCA3" },
];

export const catById = (id) => CATS.find((c) => c.id === id) || CATS[0];

export const SEED_CREATORS = [
  { id: "c1", name: "Mwansa Chileshe", location: "Lusaka, Zambia", cat: "music", bio: "Afro-fusion vocalist blending Bemba folk melodies with modern production.", achievements: "Featured on 3 regional playlists", portfolio: "soundcloud.com/mwansa" },
  { id: "c2", name: "Amara Osei", location: "Accra, Ghana", cat: "writing", bio: "Poet exploring migration, memory, and home across the diaspora.", achievements: "Published chapbook, 2025", portfolio: "amaraosei.com" },
  { id: "c3", name: "Diego Fuentes", location: "Bogotá, Colombia", cat: "film", bio: "Documentary filmmaker telling stories from Andean farming communities.", achievements: "Selected — Bogotá Shorts 2025", portfolio: "vimeo.com/diegof" },
  { id: "c4", name: "Priya Nair", location: "Kochi, India", cat: "art", bio: "Mixed-media artist reworking textile patterns into large-scale murals.", achievements: "Mural commission, Kochi Biennale", portfolio: "priyanair.art" },
  { id: "c5", name: "Tendai Moyo", location: "Bulawayo, Zimbabwe", cat: "innovation", bio: "Product designer building low-cost tools for rural creators.", achievements: "Finalist, Pan-African Innovation Prize", portfolio: "tendaimoyo.dev" },
  { id: "c6", name: "Lina Kovač", location: "Zagreb, Croatia", cat: "music", bio: "Composer scoring short films with analog synths and field recordings.", achievements: "Score credit — 4 short films", portfolio: "linakovac.bandcamp.com" },
];

export const SEED_MENTORS = [
  { id: "m1", name: "Farai Banda", role: "A&R, independent label", cat: "music", bio: "10 years helping emerging artists shape a sound and release their first EP." },
  { id: "m2", name: "Grace Adebayo", role: "Editor, literary magazine", cat: "writing", bio: "Works with young poets and essayists on voice, structure, and submissions." },
  { id: "m3", name: "Sam Okafor", role: "Documentary producer", cat: "film", bio: "Guides first-time filmmakers from concept to festival submission." },
];

export const SEED_OPPORTUNITIES = [
  { id: "o1", type: "Competition", title: "Pan-African Short Film Prize", cat: "film", deadline: "Aug 30, 2026", desc: "Open call for filmmakers under 30 telling local stories with global reach." },
  { id: "o2", type: "Grant", title: "Emerging Voices Writing Grant", cat: "writing", deadline: "Sep 12, 2026", desc: "Funding and mentorship for poets and writers publishing a first collection." },
  { id: "o3", type: "Job", title: "Junior Sound Designer, Remote", cat: "music", deadline: "Rolling", desc: "Small studio seeking a sound designer for indie game and film projects." },
  { id: "o4", type: "Collaboration", title: "Mural Collective — Nairobi", cat: "art", deadline: "Aug 5, 2026", desc: "Looking for 3 visual artists to co-create a public mural series." },
  { id: "o5", type: "Competition", title: "Youth Innovation Challenge", cat: "innovation", deadline: "Oct 1, 2026", desc: "Pitch a creative-tech idea that helps other creators; top ideas get seed funding." },
];

export const SEED_COURSES = [
  { id: "k1", cat: "music", level: "Beginner", title: "Songwriting Foundations", desc: "Structure, melody, and finding your lyrical voice." },
  { id: "k2", cat: "writing", level: "Intermediate", title: "Editing Your Own Poetry", desc: "Cut, reshape, and strengthen a draft into a finished piece." },
  { id: "k3", cat: "film", level: "Beginner", title: "Shooting on a Phone", desc: "Framing, light, and sound for no-budget filmmaking." },
  { id: "k4", cat: "art", level: "Intermediate", title: "Color for Visual Storytellers", desc: "Building a palette that carries mood and meaning." },
  { id: "k5", cat: "innovation", level: "Beginner", title: "From Idea to Prototype", desc: "Turning a creative concept into something people can try." },
];

export const SEED_POSTS = [
  { id: "p1", author: "Amara Osei", cat: "writing", text: "First draft of a new poem about my grandmother's kitchen. Feedback welcome.", ts: Date.now() - 1000 * 60 * 60 * 5 },
  { id: "p2", author: "Diego Fuentes", cat: "film", text: "Wrapped filming in the highlands today. Editing starts next week — looking for a co-editor.", ts: Date.now() - 1000 * 60 * 60 * 20 },
];

export const uid = () => Math.random().toString(36).slice(2, 10);
