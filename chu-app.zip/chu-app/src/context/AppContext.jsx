import React, { createContext, useContext, useState, useEffect, useCallback } from "react";
import {
  SEED_CREATORS,
  SEED_MENTORS,
  SEED_OPPORTUNITIES,
  SEED_COURSES,
  SEED_POSTS,
  uid,
} from "../data/seedData";

const AppContext = createContext(null);

const LS_KEYS = {
  profile: "chu_profile",
  creators: "chu_creators",
  mentors: "chu_mentors",
  posts: "chu_posts",
  saved: "chu_saved",
  connected: "chu_connected",
  requested: "chu_requested",
  applied: "chu_applied",
};

function readLS(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}
function writeLS(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* storage may be unavailable (e.g. private mode) — fail silently */
  }
}

export function AppProvider({ children }) {
  const [myProfile, setMyProfile] = useState(() => readLS(LS_KEYS.profile, null));
  const [creators, setCreators] = useState(() => readLS(LS_KEYS.creators, SEED_CREATORS));
  const [mentors, setMentors] = useState(() => readLS(LS_KEYS.mentors, SEED_MENTORS));
  const [opportunities] = useState(SEED_OPPORTUNITIES);
  const [courses] = useState(SEED_COURSES);
  const [posts, setPosts] = useState(() => readLS(LS_KEYS.posts, SEED_POSTS));

  const [connected, setConnected] = useState(() => new Set(readLS(LS_KEYS.connected, [])));
  const [requested, setRequested] = useState(() => new Set(readLS(LS_KEYS.requested, [])));
  const [saved, setSaved] = useState(() => new Set(readLS(LS_KEYS.saved, [])));
  const [applied, setApplied] = useState(() => new Set(readLS(LS_KEYS.applied, [])));

  const [toast, setToast] = useState(null);
  const showToast = useCallback((msg) => setToast(msg), []);

  useEffect(() => writeLS(LS_KEYS.profile, myProfile), [myProfile]);
  useEffect(() => writeLS(LS_KEYS.creators, creators), [creators]);
  useEffect(() => writeLS(LS_KEYS.mentors, mentors), [mentors]);
  useEffect(() => writeLS(LS_KEYS.posts, posts), [posts]);
  useEffect(() => writeLS(LS_KEYS.connected, [...connected]), [connected]);
  useEffect(() => writeLS(LS_KEYS.requested, [...requested]), [requested]);
  useEffect(() => writeLS(LS_KEYS.saved, [...saved]), [saved]);
  useEffect(() => writeLS(LS_KEYS.applied, [...applied]), [applied]);

  const saveProfile = useCallback((profile) => {
    const withId = { id: profile.id || uid(), ...profile };
    setMyProfile(withId);
    setCreators((prev) => {
      const exists = prev.some((c) => c.id === withId.id);
      return exists ? prev.map((c) => (c.id === withId.id ? withId : c)) : [withId, ...prev];
    });
    showToast("Profile saved");
    return withId;
  }, [showToast]);

  const connectWithCreator = useCallback((id) => {
    setConnected((prev) => new Set(prev).add(id));
    showToast("Connected");
  }, [showToast]);

  const requestMentor = useCallback((id) => {
    setRequested((prev) => new Set(prev).add(id));
    showToast("Mentorship request sent");
  }, [showToast]);

  const toggleSaveOpportunity = useCallback((id) => {
    setSaved((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  }, []);

  const applyToOpportunity = useCallback((id) => {
    setApplied((prev) => new Set(prev).add(id));
    showToast("Application started");
  }, [showToast]);

  const addMentor = useCallback((mentor) => {
    setMentors((prev) => [{ id: uid(), ...mentor }, ...prev]);
    showToast("Mentor profile created");
  }, [showToast]);

  const addPost = useCallback((post) => {
    setPosts((prev) => [{ id: uid(), ts: Date.now(), ...post }, ...prev]);
  }, []);

  const value = {
    myProfile, saveProfile,
    creators, mentors, opportunities, courses, posts,
    connected, connectWithCreator,
    requested, requestMentor,
    saved, toggleSaveOpportunity,
    applied, applyToOpportunity,
    addMentor, addPost,
    toast, showToast, clearToast: () => setToast(null),
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within an AppProvider");
  return ctx;
}
