/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#14102B",
        surface: "#1E1840",
        surface2: "#241C4A",
        gold: "#F2B705",
        ember: "#E8543E",
        sky: "#4EA8DE",
        violet: "#9B6BFF",
        mint: "#4ECCA3",
        mist: "#B8B3D9",
        paper: "#F5F3FF",
      },
      fontFamily: {
        display: ["Fraunces", "serif"],
        body: ["Sora", "sans-serif"],
        mono: ["IBM Plex Mono", "monospace"],
      },
    },
  },
  plugins: [],
};
